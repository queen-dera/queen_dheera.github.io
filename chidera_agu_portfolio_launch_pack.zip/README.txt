CHIDERA AGU PORTFOLIO — LAUNCH CHECKLIST

Files:
- index.html: your static portfolio website.

BEFORE PUBLISHING
1. Search in index.html for hello@chideraagu.com and https://www.linkedin.com/in/chidera-agu.
   Replace these with your verified email address and LinkedIn profile URL.
2. Review your name, positioning, services, and sample work.
3. Keep the sample projects clearly labelled as illustrative until replaced with real work.
4. Do not add invented client logos, testimonials, or performance results.

QUICK PUBLISH OPTION: GITHUB PAGES
1. Sign in to GitHub and create a public repository named username.github.io
   (replace username with your GitHub username).
2. Upload index.html to the root of that repository and commit the change.
3. Open repository Settings > Pages and select deployment from the main branch.
4. Visit https://username.github.io after deployment completes.
5. You can connect a custom domain later in Settings > Pages and configure DNS at your registrar.

DOMAIN IDEAS TO CHECK (availability is not confirmed):
- chideraagu.com
- chideraagu.co
- chideraagucontent.com

Recommended: try chideraagu.com first if available. Prefer a short .com that is easy to say,
spell, and remember. Do not buy a domain until the registrar confirms availability and renewal price.

HOSTING NOTES
This is a static HTML site; it does not require a paid server or backend to display.
GitHub Pages can host it for free on a github.io address, with custom-domain support.
Official instructions: https://docs.github.com/en/pages/quickstart
